class_name LevelManager
extends Node2D

var total := 0
var active := 0

func register_receiver(r):
	total += 1
	r.activated.connect(_on_activated)
	r.deactivated.connect(_on_deactivated)

func _on_activated():
	active += 1
	check_win()

func _on_deactivated():
	active -= 1

func check_win():
	if active == total:
		on_level_complete()

func on_level_complete():
	print("LEVEL COMPLETE")
