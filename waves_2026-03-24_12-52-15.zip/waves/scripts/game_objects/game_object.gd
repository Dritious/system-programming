class_name GameElement
extends Node2D
## Базовый класс для всех игровых элементов головоломки.
## Поддерживает размещение на сетке и drag-and-drop.

## Название элемента (для UI)
@export var element_name: String = "Элемент"

## Размер клетки сетки (в пикселях)
@export var grid_size: int = 64

## Если true — элемент нельзя перемещать (часть условий уровня)
@export var is_fixed: bool = false

## Позиция на сетке (в клетках)
var grid_pos: Vector2i = Vector2i.ZERO

## Состояние перетаскивания
var dragging: bool = false
var drag_offset: Vector2 = Vector2.ZERO


func _input(event: InputEvent) -> void:
	if is_fixed:
		return

	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed and _is_mouse_over():
			dragging = true
			drag_offset = global_position - event.position   
			z_index = 10  # Поднять над другими элементами
		elif not event.pressed and dragging:
			dragging = false
			snap_to_grid()
			z_index = 0

	if event is InputEventMouseMotion and dragging:
		global_position = event.position + drag_offset


## Привязать позицию к сетке
func snap_to_grid() -> void:
	grid_pos = Vector2i(
		roundi(position.x / grid_size),
		roundi(position.y / grid_size)
	)
	position = Vector2(grid_pos) * grid_size


## Проверить, находится ли мышь над элементом
func _is_mouse_over() -> bool:
	var mouse_pos := get_global_mouse_position()
	# Проверяем по прямоугольнику размером с клетку
	var rect := Rect2(
		global_position - Vector2(grid_size, grid_size) / 2,
		Vector2(grid_size, grid_size)
	)
	return rect.has_point(mouse_pos)
