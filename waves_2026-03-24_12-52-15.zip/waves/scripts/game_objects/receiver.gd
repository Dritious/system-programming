extends Area2D

signal activated
signal deactivated

func _ready():
	var level = get_tree().current_scene
	level.register_receiver(self)

func hit():
	activated.emit()
	print("Got it")
