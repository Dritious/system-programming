extends GameElement

## Амплитуда колебаний (максимальное отклонение)
@export var amplitude: float = 20.0

## Частота колебаний (в герцах)
@export var frequency: float = 1.5

## Скорость распространения волны (пикселей в секунду)
@export var wave_speed: float = 200.0

## Длина видимой волны (в пикселях)
@export var wave_length: float = 1000.0

@onready var line := $Line2D
@onready var ray := $RayCast2D
var time: float = 0.0
var ray_calldown: float = 0.0

func _ready() -> void:
	ray.enabled = true
	ray.collide_with_areas = true
	
func _process(delta: float) -> void:
	ray_calldown-=delta
	_ray_check()
	time+=delta
	_draw_wave()
	
func _ray_check():
	if ray.is_colliding() and ray_calldown<=0:
		var obj: Node2D = ray.get_collider()
		if obj.has_method("hit"):
			obj.hit()
			ray_calldown = 0.5

func _draw_wave() -> void:
	var points: PackedVector2Array = []
	var num_points := int(wave_length / 2.0)

	for i in range(num_points):
		var x := float(i) * 2.0
		# Формула бегущей волны: y = A * sin(2π*f*t - 2π*x/λ)
		var phase := 2.0 * PI * frequency * time - 2.0 * PI * x / wave_length
		var y := amplitude * sin(phase)
		points.append(Vector2(x, y))

	if line:
		line.points = points
	
